// Deze code stuurt een gebruiker naar het hoofdscherm als die al is ingelogd.
	var Ser = localStorage.Ile;
	var Ala = localStorage.Ger;
	if (Ser == "true" && Ala != "Egg"){
		window.location.assign("./Main.html");
	};
//Deze functie controleerd welke school je hebt uitgekozen als je op de knop drukt.
function School() {
    if (document.getElementById("school").value == "SDCA") {
        window.location.assign("./Login.html");
    } else if (document.getElementById("school").value == "none") {
       alert("Selecteer een school");
    } else {
       alert("Jouw school werkt niet met deze app.");  
    }
}