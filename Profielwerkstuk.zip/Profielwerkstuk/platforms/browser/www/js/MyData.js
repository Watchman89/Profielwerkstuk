//Dit stuk code stuurt de gebruiker weg als die niet is ingelogd.
	if (sessionStorage.Ile){
		var Ile = sessionStorage.Ile;
		var Ger = sessionStorage.Ger;
	}else{
		var Ile = localStorage.Ile;
		var Ger = localStorage.Ger;
	};
	if (Ile != "true"){
		window.location.assign("./Login.html");
	};
//Deze functie vult alle gegevens van de gebruiker aan.
function onLoad() {
	document.getElementById("plaatje").src = "./img/" + PersDat[Ger].leerNum + ".png";
	document.getElementById("naam").innerHTML = PersDat[Ger].Naam;
	document.getElementById("birth").innerHTML = PersDat[Ger].Birth;	
	document.getElementById("adres").innerHTML = PersDat[Ger].Adres;
	document.getElementById("study").innerHTML = PersDat[Ger].Study;
	document.getElementById("profile").innerHTML = PersDat[Ger].Profile;
	document.getElementById("klas").innerHTML = PersDat[Ger].Klas;
	document.getElementById("leerNum").innerHTML = PersDat[Ger].leerNum;
	document.getElementById("exNum").innerHTML = PersDat[Ger].exNum;
	document.getElementById("persMent").innerHTML = PersDat[Ger].persMent;
	document.getElementById("klasMent").innerHTML = PersDat[Ger].klasMent;
	document.getElementById("email").innerHTML = PersDat[Ger].email;
	document.getElementById("phoneNum").innerHTML = PersDat[Ger].phoneNum;
};