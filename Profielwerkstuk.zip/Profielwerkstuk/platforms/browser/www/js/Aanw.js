//Dit stuk code stuurt de gebruiker weg als die niet is ingelogd.
	if (sessionStorage.Ile){
		var Ile = sessionStorage.Ile;
		var Ger = sessionStorage.Ger;
	}else{
		var Ile = localStorage.Ile;
		var Ger = localStorage.Ger;
	};
	if (Ile != "true"){
		window.location.assign("./Login.html");
	};
//Deze functie laad alle afwezigheden van een gebruiker.
function Beginn() {
	var Asn = PersDat[Ger].Naam;
	var Pro = document.getElementById("Bubbles");
	var Arg = Pro.rows.length;
	for(i=0;i<Leave.length;i++){
		if (Asn == Leave[i].Wie){
			var Row = Pro.insertRow(Arg);
			var Cell0 = Row.insertCell(0);
			var Cell1 = Row.insertCell(1);
			var Cell2 = Row.insertCell(2);
			Cell0.innerHTML = Leave[i].Wat;
			Cell1.innerHTML = Leave[i].Dag;
			Cell2.innerHTML = Leave[i].Uur;
		};
	};
};