//Alle gebruikersdata staat in dit bestand.
//Overig
var Rooster = [];
var Gebrnaam = "Egg";
var Authenticate = false;
var datum = new Date();
//Inloggegevens
var LogDat = [
    {"User" : "raplatte", "Pass" : "d4jdyviw"},
    {"User" : "meminten", "Pass" : "g8yj2ee0"},
    {"User" : "mickher", "Pass" : "k1l00ucn"}
];
//Roosters
switch (datum.getDay()) {
	case 1:
		Rooster = [
		{"Klas" : "6A1", "first" : "Informatica","second" : "Biologie","third" : "Scheikunde","fourth" : "Daltonuur","fifth" : "Wiskunde","sixth" : "Duits"},
		{"Klas" : "5A1", "first" : "Biologie","second" : "Spaans","third" : "Duits","fourth" : "Daltonuur","fifth" : "Economie"},
		{"Klas" : "4A2", "first" : "Wiskunde","second" : "Wiskunde","third" : "Nederlands","fourth" : "Daltonuur","fifth" : "Engels"}
		];
		break;
	case 2:
		Rooster = [
		{"Klas" : "6A1", "first" : "Informatica","second" : "Biologie","third" : "Scheikunde","fourth" : "Daltonuur","fifth" : "Wiskunde","sixth" : "Duits"},
		{"Klas" : "5A1", "first" : "Biologie","second" : "Spaans","third" : "Duits","fourth" : "Daltonuur","fifth" : "Economie"},
		{"Klas" : "4A2", "first" : "Wiskunde","second" : "Wiskunde","third" : "Nederlands","fourth" : "Daltonuur","fifth" : "Engels"}
		];
		break;
	case 3:
		Rooster = [
		{"Klas" : "6A1", "first" : "Informatica","second" : "Biologie","third" : "Scheikunde","fourth" : "Daltonuur","fifth" : "Wiskunde","sixth" : "Duits"},
		{"Klas" : "5A1", "first" : "Biologie","second" : "Spaans","third" : "Duits","fourth" : "Daltonuur","fifth" : "Economie"},
		{"Klas" : "4A2", "first" : "Wiskunde","second" : "Wiskunde","third" : "Nederlands","fourth" : "Daltonuur","fifth" : "Engels"}
		];
		break;
	case 4:
		Rooster = [
		{"Klas" : "6A1", "first" : "Informatica","second" : "Biologie","third" : "Scheikunde","fourth" : "Daltonuur","fifth" : "Wiskunde","sixth" : "Duits"},
		{"Klas" : "5A1", "first" : "Biologie","second" : "Spaans","third" : "Duits","fourth" : "Daltonuur","fifth" : "Economie"},
		{"Klas" : "4A2", "first" : "Wiskunde","second" : "Wiskunde","third" : "Nederlands","fourth" : "Daltonuur","fifth" : "Engels"}
		];
		break;
	case 5:
		Rooster = [
		{"Klas" : "6A1", "first" : "Informatica","second" : "Biologie","third" : "Scheikunde","fourth" : "Daltonuur","fifth" : "Wiskunde","sixth" : "Duits"},
		{"Klas" : "5A1", "first" : "Biologie","second" : "Spaans","third" : "Duits","fourth" : "Daltonuur","fifth" : "Economie"},
		{"Klas" : "4A2", "first" : "Wiskunde","second" : "Wiskunde","third" : "Nederlands","fourth" : "Daltonuur","fifth" : "Engels"}
		];
		break;
	default:
		var Rooster = null;
}
//Alle persoonlijke gegevens.
var PersDat = [
	{"Naam" : "Rik Platte", "Klas" : "6A1", "Birth" : "17-05-2000", "Adres" : "Bannewaard 16 Alkmaar", "Study" : "VWO6", "Profile" : "NT/NG", "leerNum" : "1002093", "exNum" : "112", "persMent" : "N.J.L. De Vries", "klasMent" : "N.J.L. De Vries, J.M. Schrander", "email" : "rplatte@hotmail.nl", "phoneNum" : "0637337456"},
	{"Naam" : "Melle Minten", "Klas" : "5A1", "Birth" : "31-08-1999", "Adres" : "Rotterdamlaan 8 Alkmaar", "Study" : "VWO5", "Profile" : "NT/NG", "leerNum" : "1002083", "exNum" : "", "persMent" : "J.M. Schrander", "klasMent" : "J.M. Schrander", "email" : "melleminten@gmail.com", "phoneNum" : "0609264982"},
	{"Naam" : "Micky Hermans", "Klas" : "2M3", "Birth" : "2-12-1998", "Adres" : "Oldenzaalstraat 41 Almere", "Study" : "VMBO4", "Profile" : "CM", "leerNum" : "1001999", "exNum" : "", "persMent" : "J.P. Jambroes", "klasMent" : "J.P.Jambroes, J. Hendriks", "email" : "micky.hermans@gmail.com", "phoneNum" : "0693759360"}
];
//Afwezigheden
var Leave = [
	{"Wie" : "Rik Platte", "Wat" : "GF", "Dag" : "11-11-2016" , "Uur" : "6e"},
	{"Wie" : "Kevin Smit", "Wat" : "TL", "Dag" : "6-8-2016" , "Uur" : "1e"},
	{"Wie" : "Tanja Vasquez", "Wat" : "GA", "Dag" : "5-5-2016" , "Uur" : "7e"},
	{"Wie" : "Kevin Smit", "Wat" : "TL", "Dag" : "15-8-2016" , "Uur" : "1e"},
	{"Wie" : "Melle Minten", "Wat" : "GA", "Dag" : "17-9-2016" , "Uur" : "1e"},
	{"Wie" : "Rik Platte", "Wat" : "OO", "Dag" : "16-9-2016" , "Uur" : "4e"}
];
//Cijfers
var Cijfers = [
	{"Wie" : "Melle Minten" , "Vak" : "Engels" , "Beschrijving" : "Essay Engels" , "Datum" : "8-8-2016" , "Cijfer" : 6.9 , "Weging" : "10"},
	{"Wie" : "Melle Minten" , "Vak" : "Engels" , "Beschrijving" : "Vocab Book 1" , "Datum" : "11-11-2016" , "Cijfer" : 5.6, "Weging" : "10"},
	{"Wie" : "Melle Minten" , "Vak" : "Engels" , "Beschrijving" : "Grammar" , "Datum" : "25-9-2016" , "Cijfer" : 7.1, "Weging" : "15"},
	{"Wie" : "Melle Minten" , "Vak" : "Scheikunde" , "Beschrijving" : "H8" , "Datum" : "8-9-2016" , "Cijfer" : 5.8, "Weging" : "10"},
	{"Wie" : "Melle Minten" , "Vak" : "Scheikunde" , "Beschrijving" : "H7" , "Datum" : "12-11-2016" , "Cijfer" : 7.6, "Weging" : "15"},
	{"Wie" : "Melle Minten" , "Vak" : "Nederlands" , "Beschrijving" : "Literatuurtheorie" , "Datum" : "6-10-2016" , "Cijfer" : 6.6, "Weging" : "20"},
	{"Wie" : "Melle Minten" , "Vak" : "Duits" , "Beschrijving" : "Luistertoets" , "Datum" : "8-8-2016" , "Cijfer" : 7.1, "Weging" : "10"},
	{"Wie" : "Rik Platte" , "Vak" : "Engels" , "Beschrijving" : "Tentamen 1" , "Datum" : "11-11-2016" , "Cijfer" : 7.4, "Weging" : "25"},
	{"Wie" : "Rik Platte" , "Vak" : "Nederlands" , "Beschrijving" : "Tentamen 1" , "Datum" : "11-11-2016" , "Cijfer" : 6.8, "Weging" : "33"},
	{"Wie" : "Rik Platte" , "Vak" : "Natuurkunde" , "Beschrijving" : "Tentamen 1" , "Datum" : "12-11-2016" , "Cijfer" : 8.1, "Weging" : "25"},
	{"Wie" : "Rik Platte" , "Vak" : "Economie" , "Beschrijving" : "Tentamen 1" , "Datum" : "10-11-2016" , "Cijfer" : 6.9, "Weging" : "25"},
	{"Wie" : "Rik Platte" , "Vak" : "Duits" , "Beschrijving" : "SO 1" , "Datum" : "8-10-2016" , "Cijfer" : 10, "Weging" : "1"},
	{"Wie" : "Micky Hermans" , "Vak" : "Nederlands" , "Beschrijving" : "Leestoetes" , "Datum" : "9-8-2016" , "Cijfer" : 5.3, "Weging" : "10"},
	{"Wie" : "Micky Hermans" , "Vak" : "Wiskunde" , "Beschrijving" : "H2" , "Datum" : "9-11-2016" , "Cijfer" : 7.6, "Weging" : "15"},
	{"Wie" : "Micky Hermans" , "Vak" : "Dans" , "Beschrijving" : "Uitvoering" , "Datum" : "19-7-2016" , "Cijfer" : 8, "Weging" : "15"}
];
var Vakken = {
	1002093: ['Nederlands','Engels','Wiskunde B','Economie','Duits','Natuurkunde','Scheikunde','OSB','Biologie','Informatica','Mentorles'],
	1002083: ['Nederlands','Engels','Wiskunde B','Economie','Duits','Natuurkunde','Scheikunde','OSB','Biologie','Informatica','Mentorles','Gym'],
	1001999: ['Nederlands','Engels','Wiskunde','KV','Dans','Gym','Science','Mentorles']
};