//Dit stuk code stuurt de gebruiker weg als die niet is ingelogd.
	if (sessionStorage.Ile){
		var Ile = sessionStorage.Ile;
		var Ger = sessionStorage.Ger;
	}else{
		var Ile = localStorage.Ile;
		var Ger = localStorage.Ger;
	};
	if (Ile != "true"){
		window.location.assign("./Login.html");
	};
//Deze functie logt de gebruiker uit als hij op de knop drukt.
function LogOff() {
	localStorage.removeItem("Ile");
	localStorage.removeItem("Ger");
	sessionStorage.removeItem("Ile");
	sessionStorage.removeItem("Ger");
	window.location.assign("./Login.html");
};
