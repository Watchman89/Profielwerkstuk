//Dit stuk code stuurt de gebruiker weg als die niet is ingelogd.
	if (sessionStorage.Ile){
		var Ile = sessionStorage.Ile;
		var Ger = sessionStorage.Ger;
	}else{
		var Ile = localStorage.Ile;
		var Ger = localStorage.Ger;
	};
	if (Ile != "true"){
		window.location.assign("./Login.html");
	};