// Deze code stuurt een gebruiker naar het hoofdscherm als die al is ingelogd.
	var Ser = localStorage.Ile;
	var Ala = localStorage.Ger;
	if (Ser == "true" && Ala != "Egg"){
		window.location.assign("./Main.html");
	};
// Deze functie neemt wat je hebt ingevuld en vergelijkt het met waarden
// uit een bestand. Als ze overeen komen log je in.
function Login() {
	var UserName = document.getElementById("Gebr").value;
	var PassWord = document.getElementById("Wach").value;
    for (i = 0; i < LogDat.length; i++) {		
        if (UserName == LogDat[i].User && PassWord == LogDat[i].Pass) {
                Authenticate = true;
                Gebrnaam = "Leerling" + i.toString();
				if (document.getElementById('KeepOn').checked) {
					localStorage.Ile = "true";
					localStorage.Ger = i.toString();
				}else{
					sessionStorage.Ile = "true";
					sessionStorage.Ger = i.toString();	
				};
				break;
        }
    }
    if (Authenticate == true) {
        window.location.assign("./Main.html");
    }
    else {alert("De gegevens zijn incorrect.");}
}