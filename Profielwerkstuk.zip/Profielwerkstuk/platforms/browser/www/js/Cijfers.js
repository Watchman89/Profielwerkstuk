//Dit stuk code stuurt de gebruiker weg als die niet is ingelogd.
	if (sessionStorage.Ile){
		var Ile = sessionStorage.Ile;
		var Ger = sessionStorage.Ger;
	}else{
		var Ile = localStorage.Ile;
		var Ger = localStorage.Ger;
	};
	if (Ile != "true"){
		window.location.assign("./Login.html");
	};
//Dit stuk code kan laten controleren of een waarde in een array staat.(later nodig)
Array.prototype.contains = function(obj) {
    var i = this.length;
    while (i--) {
        if (this[i] === obj) {
            return true;
        }
    }
    return false;
}
//Deze functie vult alle vakken aan en daarna alle cijfers die een leerling daarvan
//heeft ontvangen.
function fillEm() {
	var Num = PersDat[Ger].leerNum;
	var VakLst = Vakken[Num];
	var Name = PersDat[Ger].Naam;
	var Phe = document.getElementById("numTable");
	var Tyr = Phe.rows.length;
	for (i=0 ; i<VakLst.length ; i++) {
		var Row = Phe.insertRow(Tyr);
		var Cell0 = Row.insertCell(0);
		Cell0.innerHTML = Vakken[Num][i];
		Cell0.onclick = fillOne(Cell0.innerHTML);
//		Cell0.style.width = "80%";	
//		var Cell1 = Row.insertCell(1);
	};
};
//Deze functie vult de tabel met de cijfers van één vak.
function fillOne(Vak) {
	for (n=0 ; Phe.length!=0 ; n++) {
		Phe.deleteRow(n);
	};
	
};