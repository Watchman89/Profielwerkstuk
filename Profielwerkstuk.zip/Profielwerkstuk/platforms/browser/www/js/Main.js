//Dit stuk code stuurt de gebruiker weg als die niet is ingelogd.
	if (sessionStorage.Ile != undefined){
		var Ile = sessionStorage.Ile;
		var Ger = sessionStorage.Ger;
	}else{
		var Ile = localStorage.Ile;
		var Ger = localStorage.Ger;
	};
	if (Ile != "true"){
		window.location.assign("./Login.html");
	};
//Deze functie laad het rooster van de ingelogde persoon.
function onComp() {
	var Klas = PersDat[Ger].Klas;
	for(c = 0;c < Rooster.length; c++){
		if (Rooster[c].Klas == Klas) {
			if (Rooster[c].seventh == null){
				document.getElementById("tabel").deleteRow(7);
			}else{
				document.getElementById("zeven").innerHTML = "7e " + Rooster[c].seventh;
			};
			if (Rooster[c].sixth == null){
				document.getElementById("tabel").deleteRow(6);
			}else{
				document.getElementById("zes").innerHTML = "6e " + Rooster[c].sixth;
			};
			if (Rooster[c].fifth == null){
				document.getElementById("tabel").deleteRow(5);
			}else{
				document.getElementById("vijf").innerHTML = "5e " + Rooster[c].fifth;
			};
			if (Rooster[c].fourth == null){
				document.getElementById("tabel").deleteRow(4);
			}else{
				document.getElementById("vier").innerHTML = "4e " + Rooster[c].fourth;
			};
			if (Rooster[c].third == null){
				document.getElementById("tabel").deleteRow(3);
			}else{
				document.getElementById("drie").innerHTML = "3e " + Rooster[c].third;
			};
			if (Rooster[c].second == null){
				document.getElementById("tabel").deleteRow(2);
			}else{
				document.getElementById("twee").innerHTML = "2e " + Rooster[c].second;
			};
			if (Rooster[c].first == null){
				document.getElementById("tabel").deleteRow(1);
			}else{
				document.getElementById("een").innerHTML = "1e " + Rooster[c].first;
			};			
		};
	};
}
//Alle knoppen staan hier.
function ToAgenda(){
	window.location.assign("./Agenda.html");
}
function ToCijfers(){
	window.location.assign("./Cijfers.html");
}
function ToMail() {
	window.location.assign("./Mail.html");
}
function ToELO() {
	window.location.assign("./ELO.html");
}
function ToAanw() {
	window.location.assign("./Aanw.html");
}
function ToMyData() {
	window.location.assign("./MyData.html");
}
function ToAbout() {
	window.location.assign("./Over.html");
}
function ToOptions() {
	window.location.assign("./Opties.html");
}